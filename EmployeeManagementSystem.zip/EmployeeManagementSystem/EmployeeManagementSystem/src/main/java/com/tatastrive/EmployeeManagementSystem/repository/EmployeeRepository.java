package com.tatastrive.EmployeeManagementSystem.repository;

import com.tatastrive.EmployeeManagementSystem.entity.Employee1;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee1,Integer> {
}
