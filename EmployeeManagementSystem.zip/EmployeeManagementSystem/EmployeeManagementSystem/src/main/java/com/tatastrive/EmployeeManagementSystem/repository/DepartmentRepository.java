package com.tatastrive.EmployeeManagementSystem.repository;

import com.tatastrive.EmployeeManagementSystem.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartmentRepository extends JpaRepository<Department, Integer> {
}
