package com.tatastrive.EmployeeManagementSystem.repository;


import com.tatastrive.EmployeeManagementSystem.entity.Project;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectRepository extends JpaRepository<Project,Integer> {
}
