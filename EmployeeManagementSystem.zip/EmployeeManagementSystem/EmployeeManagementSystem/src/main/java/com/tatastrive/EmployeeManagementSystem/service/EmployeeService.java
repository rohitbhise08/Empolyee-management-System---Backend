package com.tatastrive.EmployeeManagementSystem.service;


import com.tatastrive.EmployeeManagementSystem.entity.Department;
import com.tatastrive.EmployeeManagementSystem.entity.Employee1;
import com.tatastrive.EmployeeManagementSystem.entity.Project;
import com.tatastrive.EmployeeManagementSystem.repository.DepartmentRepository;
import com.tatastrive.EmployeeManagementSystem.repository.EmployeeRepository;
import com.tatastrive.EmployeeManagementSystem.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {
    @Autowired
    EmployeeRepository employeeRepository;

    @Autowired
    DepartmentRepository departmentRepository;

    @Autowired
    ProjectRepository projectRepository;

    public String addEmployee(Employee1 employee1){
        employeeRepository.save(employee1);
        return "Employee Added Successfully";
    }
    //view All employees
    public List<Employee1> getAllEmployee(){
        return employeeRepository.findAll();
    }
    //search Employee by Id
    public Employee1 searchEmployee (int id ) {
        return employeeRepository.findById(id).orElse(null);
    }
    //update Employee
    public String updateEmployee(Employee1 employee1){
        employeeRepository.save(employee1);
        return "Employee update Successfully";
    }
    //delete Employee
    public String deleteEmployee (int id){
        employeeRepository.deleteById(id);
        return "Employee deleted Successfully";
    }
    //add departement
    public String addDepartment(Department department){
        departmentRepository.save(department);
        return "Department added succssfully";
    }
    //add project
    public String addProject(Project project){
        projectRepository.save(project);
        return "project Added Successfully";
    }

}
