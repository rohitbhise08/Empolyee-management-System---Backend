package com.tatastrive.EmployeeManagementSystem.controller;

import com.tatastrive.EmployeeManagementSystem.entity.Department;
import com.tatastrive.EmployeeManagementSystem.entity.Employee1;
import com.tatastrive.EmployeeManagementSystem.entity.Project;
import com.tatastrive.EmployeeManagementSystem.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
    @Autowired
    EmployeeService service;

    //add Emploee
    @PostMapping("/add")
    public String addEmploee(@RequestBody Employee1 employee1){
        return service.addEmployee(employee1);
    }


    //view all emploee
    @GetMapping("/all")
    public List<Employee1> getEmmployee(){
        return service.getAllEmployee();
    }

    //search Employee
    @GetMapping("{id}")
    public Employee1 searchEmployee(@PathVariable int id){
        return service.searchEmployee(id);
    }

    //delete Employee
    @DeleteMapping("/delete/{id}")
public String deleteEmployee(@PathVariable int id){
        return service.deleteEmployee(id);
}

    //add department
    @PostMapping("/department")
    public String addDepartment(@RequestBody Department department){
            return service.addDepartment(department);
    }

    //add Projject
    @PostMapping("/project")
    public String addProject(@RequestBody Project project){
        return service.addProject(project);
    }
}
