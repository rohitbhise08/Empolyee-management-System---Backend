package com.tatastrive.EmployeeManagementSystem.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Employee1 {
    @Id
    private int empId;
    private String empName;
    private String designation;
    private double salary;

    public Employee1(){

    }

    public Employee1(int empId, String empName , String designation, double salary){
        super();
        this.empId=empId;
        this.empName=empName;
        this.designation=designation;
        this.salary=salary;
    }

    public int getEmpId() {
        return empId;
    }
    public String getEmpName(){
        return empName;
    }
    public String getDesignation(){
        return designation;
    }

    public double getSalary() {
        return salary;
    }
    public void setEmpId(int empId){
        this.empId=empId;
    }
    public void setEmpName(String empName){
        this.empName=empName;
    }
    public void setDesignation(String designation){
        this.designation=designation;
    }
    public void setSalary(double salary){
        this.salary=salary;
    }
}
