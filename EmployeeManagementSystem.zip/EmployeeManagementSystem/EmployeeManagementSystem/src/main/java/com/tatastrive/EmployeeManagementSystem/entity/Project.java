package com.tatastrive.EmployeeManagementSystem.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

/*

Project.java
   |
   |
 project Table
 hibernate creates table
 */
@Entity
public class Project {
    @Id
    private int projectId;
    private String projectName;
    private String clientName;

    private Project(){

    }
    public Project(int projectId,String projectName,String clientName){
        super();
        this.projectId=projectId;
        this.projectName=projectName;
        this.clientName=clientName;
    }

    public int getProjectId() {
        return projectId;
    }

    public String getProjectName(){
        return projectName;
    }
    public String getClientName(){
        return clientName;
    }
    public void setProjectId(int projectId){
        this.projectId=projectId;
    }
    public void setProjectName(String projectName){
        this.projectName=projectName;
    }
    public void setClientName(String clientName){
        this.clientName=clientName;
    }
}
