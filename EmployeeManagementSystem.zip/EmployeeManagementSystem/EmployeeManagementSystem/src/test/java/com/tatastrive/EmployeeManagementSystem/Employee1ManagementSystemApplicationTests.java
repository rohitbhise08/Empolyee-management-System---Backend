package com.tatastrive.EmployeeManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Employee1ManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
