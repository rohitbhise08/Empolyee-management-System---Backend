package com.tatastrive.EmployeeDatabaseConnectivity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeDatabaseConnectivityApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeDatabaseConnectivityApplication.class, args);
	}

}
