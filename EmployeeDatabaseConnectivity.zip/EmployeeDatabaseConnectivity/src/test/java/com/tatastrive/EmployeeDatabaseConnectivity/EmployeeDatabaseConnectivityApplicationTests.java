package com.tatastrive.EmployeeDatabaseConnectivity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeDatabaseConnectivityApplicationTests {

	@Test
	void contextLoads() {
	}

}
