package com.tatastrive.learnerDatabaseManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnerDatabaseManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnerDatabaseManagementSystemApplication.class, args);
	}

}
